package proyectofinal;
import javax.swing.JOptionPane;
public class Pizza {
    private String ingredientes;
    private String porciones;
    private String tamaño;
    private String precioPizza;
    
    public Pizza() {
        this.ingredientes= "";
        this.porciones= "";
        this.tamaño= "";
        this.precioPizza= "";
    }

    public String getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(String ingredientes) {
        this.ingredientes = ingredientes;
    }

    public String getPorciones() {
        return porciones;
    }

    public void setPorciones(String porciones) {
        this.porciones = porciones;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public String getPrecioPizza() {
        return precioPizza;
    }

    public void setPrecioPizza(String precioPizza) {
        this.precioPizza = precioPizza;
    }
    
    
}
