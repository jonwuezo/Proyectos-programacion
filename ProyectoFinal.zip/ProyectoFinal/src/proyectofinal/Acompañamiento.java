package proyectofinal;
import javax.swing.JOptionPane;
public class Acompañamiento {
    private String refrescos;
    private String panAjo;
    private String breadsticks;
    private String salsas;
    
    public Acompañamiento() {
        this.refrescos= "";
        this.panAjo= "";
        this.breadsticks= "";
        this.salsas= "";
    }

    public String getRefrescos() {
        return refrescos;
    }

    public void setRefrescos(String refrescos) {
        this.refrescos = refrescos;
    }

    public String getPanAjo() {
        return panAjo;
    }

    public void setPanAjo(String panAjo) {
        this.panAjo = panAjo;
    }

    public String getBreadsticks() {
        return breadsticks;
    }

    public void setBreadsticks(String breadsticks) {
        this.breadsticks = breadsticks;
    }

    public String getSalsas() {
        return salsas;
    }

    public void setSalsas(String salsas) {
        this.salsas = salsas;
    }
    
}
