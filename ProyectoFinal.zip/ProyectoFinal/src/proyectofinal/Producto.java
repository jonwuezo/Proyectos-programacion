package proyectofinal;
import javax.swing.JOptionPane;
public class Producto {
    private int codProducto;
    private String nombreProducto;
    private double precio;
    private String aplicaDescuento;
    
    public Producto() {
        this.codProducto= 0;
        this.nombreProducto= "";
        this.precio= 0.00;
        this.aplicaDescuento= "";
    }

    public int getCodProducto() {
        return codProducto;
    }

    public void setCodProducto(int codProducto) {
        this.codProducto = codProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getAplicaDescuento() {
        return aplicaDescuento;
    }

    public void setAplicaDescuento(String aplicaDescuento) {
        this.aplicaDescuento = aplicaDescuento;
    }
    
    
    
}
