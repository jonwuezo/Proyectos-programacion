package proyectofinal;
import javax.swing.JOptionPane;
public class CodigoReferencia {
    private int codigoEnvio;
    private String informacionPedido;
    private int montoTotal;
    
    public CodigoReferencia() {
        this.codigoEnvio= 0;
        this.informacionPedido= "";
        this.montoTotal= 0;
    }

    public int getCodigoEnvio() {
        return codigoEnvio;
    }

    public void setCodigoEnvio(int codigoEnvio) {
        this.codigoEnvio = codigoEnvio;
    }

    public String getInformacionPedido() {
        return informacionPedido;
    }

    public void setInformacionPedido(String informacionPedido) {
        this.informacionPedido = informacionPedido;
    }

    public int getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(int montoTotal) {
        this.montoTotal = montoTotal;
    }

    boolean getCodigoEnvio(String referencia) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
