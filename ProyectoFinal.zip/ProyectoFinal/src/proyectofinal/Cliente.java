package proyectofinal;
import javax.swing.JOptionPane;
public class Cliente {
    private String nombreCliente;
    private String primerApellido;
    private String segundoApellido;
    private int telefono;
    private String ubicacion;
    
    public Cliente() {
        this.nombreCliente= "";
        this.primerApellido= "";
        this.segundoApellido= "";
        this.telefono= 0;
        this.ubicacion= "";
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getPrimerApellido() {
        return primerApellido;
    }

    public void setPrimerApellido(String primerApellido) {
        this.primerApellido = primerApellido;
    }

    public String getSegundoApellido() {
        return segundoApellido;
    }

    public void setSegundoApellido(String segundoApellido) {
        this.segundoApellido = segundoApellido;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }
    
}
