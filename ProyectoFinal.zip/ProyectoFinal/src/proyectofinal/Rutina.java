package proyectofinal;
import javax.swing.JOptionPane;
public class Rutina {
    private Cliente cliente[]= new Cliente[1];
    private Producto producto[]= new Producto[1];
    private Descuento descuento[]= new Descuento[1];
    private Restaurante restaurante[]= new Restaurante[1];
    private Pizza pizza[]= new Pizza[1];
    private Factura factura[]= new Factura[1];
    private CodigoReferencia codigoreferencia[]= new CodigoReferencia[1];
    private Acompañamiento acompañamiento[]= new Acompañamiento[1];
    private String s= "";
    private String c= "";
    private double total;
    private double referencia;
    
    public void mostrarMenu() {
        int opc=0;
        while(opc!=8) {
            opc=Integer.parseInt(JOptionPane.showInputDialog(null,
                    "***MENU PRINCIPAL DE FIDEPIZZA***\n\n"
                            +"1.Ver menu\n"
                            +"2.Pedir pizza\n"
                            +"3.Ver precio\n"
                            +"4. Ver tamaños\n"
                            +"5.Ver acompañamientos\n"
                            +"6.Ver restuarantes disponibles\n"
                            +"7.Ver nuestro numero de quejas o sugerencias\n"
                            +"8.Salir\n\n"
                            +"Digite su opcion:"));
            switch(opc){
                case 1:{
                    verMenu();
                    break;
                }
                case 2:{
                    llenarArreglo();
                    mostrarArreglo();
                    crearDescuento();
                    crearCodigoReferencia();
                    break;
                }
                case 3:{
                    verPrecio();
                    break;
                }
                case 4:{
                    verTamaño();
                    break;
                }
                case 5:{
                    verAcompañamiento();
                    break;
                }
                case 6:{
                    verRestaurante();
                    break;
                }
                case 7:{
                    verNumero();
                    break;
                }
                case 8:{
                    System.exit(0);
                    break;
                }
                default:{
                    JOptionPane.showMessageDialog(null,"Opcion Incorrecta");
                }
            }
        }
    }
    
    public  void llenarArreglo() {
        int x;
        for (x=0; x<1; x++) {
            Cliente clien= new Cliente();
            Producto prod= new Producto();
            Descuento desc= new Descuento();
            Restaurante res= new Restaurante();
            Pizza pi= new Pizza();
            Factura fac= new Factura();
            CodigoReferencia cod= new CodigoReferencia();
            Acompañamiento acom= new Acompañamiento();
            
            clien.setNombreCliente(JOptionPane.showInputDialog(null,"Digite su nombre:"));
            clien.setPrimerApellido(JOptionPane.showInputDialog(null,"Digite su primer apellido:"));
            clien.setSegundoApellido(JOptionPane.showInputDialog(null,"Digite su segundo apellido:"));
            clien.setTelefono(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite su numero de telefono:")));
            clien.setUbicacion(JOptionPane.showInputDialog(null,"Digite en donde quiere que llegue su pizza:"));
            
            prod.setCodProducto(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el codigo que usted desee:")));
            prod.setNombreProducto(JOptionPane.showInputDialog(null,"Digite de que tamaño desea la pizza:"));
            prod.setPrecio(Double.parseDouble(JOptionPane.showInputDialog(null, "Digite el precio de la pizza:")));
            
            JOptionPane.showMessageDialog(null, "Esta semana es la apertura de nuestro restaurante y tendremos un 10% de descuento");
            JOptionPane.showMessageDialog(null,"El nombre del restaurante es Fidepizza y nuestro restaurante se encuentra en San Pedro");
            
            res.setNombre(JOptionPane.showInputDialog(null,"Digite el nombre del restaurante:"));
            res.setUbicacionRes(JOptionPane.showInputDialog(null,"Digite la ubicacion del restaurante:"));
            res.setNumero(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite nuevamente su telefono:")));
            res.setEmail(JOptionPane.showInputDialog(null,"Digite su correo electronico:"));
            
            JOptionPane.showMessageDialog(null,"En nuestro restaurante usted puede escoger sus propios ingredientes");
            
            pi.setIngredientes(JOptionPane.showInputDialog(null,"Digite los ingredientes que desea en su pizza:"));
            pi.setPorciones(JOptionPane.showInputDialog(null,"Digite las porciones que desea en su pizza:"));
            pi.setTamaño(JOptionPane.showInputDialog(null,"Digite si desea su pizza Pequeña ,Mediana, Grande:"));
            pi.setPrecioPizza(JOptionPane.showInputDialog(null,"Digite el precio de la pizza:"));
            
            JOptionPane.showMessageDialog(null,"Yo soy el vendedor y mi nombre es Alex");
            
            fac.setNumeroFactura(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite el codigo de factura que desea:")));
            fac.setFecha(JOptionPane.showInputDialog(null,"Digite el mes actual:"));
            fac.setMetodoPago(JOptionPane.showInputDialog(null,"Digite si desea pagar en efectivo o en tarjeta:"));
            
            acom.setRefrescos(JOptionPane.showInputDialog(null,"Digite si desea refrescos:"));
            acom.setPanAjo(JOptionPane.showInputDialog(null,"Digite si desea Pan de Ajo:"));
            acom.setBreadsticks(JOptionPane.showInputDialog(null,"Digite si desea Breadsticks:"));
            acom.setSalsas(JOptionPane.showInputDialog(null,"Digite si desea salsas:"));
            
            cod.setCodigoEnvio(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite de nuevo el codigo:")));
            cliente[x]= clien;
            producto[x]=prod;
            restaurante[x]=res;
            pizza[x]=pi;
            factura[x]=fac;
            acompañamiento[x]=acom;
            codigoreferencia[x]=cod;
        }
    }
    
    public void mostrarArreglo() {
        int x;
        for (x=0; x<1; x++) {
            s=s+cliente[x].getNombreCliente()+"."+
                    cliente[x].getPrimerApellido()+"."+
                    cliente[x].getSegundoApellido()+"."+
                    cliente[x].getTelefono()+"."+
                    cliente[x].getUbicacion()+".";
            
            s=s+producto[x].getCodProducto()+"."+
                    producto[x].getNombreProducto()+"."+
                    producto[x].getPrecio()+"."+
                    producto[x].getAplicaDescuento()+".";
            
            total=total+producto[x].getPrecio();
            
            s=s+restaurante[x].getNombre()+"."+
                    restaurante[x].getUbicacionRes()+"."+
                    restaurante[x].getNumero()+"."+
                    restaurante[x].getEmail()+".";
            
            s=s+pizza[x].getIngredientes()+"."+
                    pizza[x].getPorciones()+"."+
                    pizza[x].getTamaño()+"."+
                    pizza[x].getPrecioPizza()+".";
            
            s=s+factura[x].getNumeroFactura()+"."+
                    factura[x].getFecha()+"."+
                    factura[x].getMetodoPago()+".";
            
            s=s+acompañamiento[x].getRefrescos()+"."+
                    acompañamiento[x].getPanAjo()+"."+
                    acompañamiento[x].getBreadsticks()+"."+
                    acompañamiento[x].getSalsas()+"."+"\n\n\nTotal:"+total;
        }
        JOptionPane.showMessageDialog(null,"Esta es la informacion que usted nos dio:\n"+s);
    }
    
    public void crearDescuento() {
        int x,s=0;
        double descuento=0;
        for (x=0; x<1; x++) {
            if (pizza[x].getPrecioPizza().equals("4000")) {
                descuento= descuento - 400;
                
                if (pizza[x].getPrecioPizza().equals("8000")) {
                    descuento= descuento - 800;
                    
                    if(pizza[x].getPrecioPizza().equals("12000")) {
                        descuento= descuento - 1200;
                    }
                }
            }
        }
        JOptionPane.showMessageDialog(null,"Este es el precio total de la pizza mas el agregado del delivery es:\n"+(total-descuento));
    }
    
    public void crearCodigoReferencia() {
        int x;
        for(x=0; x<1; x++) {
            c= c+codigoreferencia[x].getCodigoEnvio()+".";
        }
        JOptionPane.showMessageDialog(null,"Este es el codigo que le debe enseñar al delivery:\n"+c);
    }
    
    public void verMenu() {
        JOptionPane.showMessageDialog(null,"En este restaurante usted puede crear su propia pizza");
    }
    
    public void verPrecio() {
        JOptionPane.showMessageDialog(null,"El tamaño de las pizzas son: Pequeña con un precio de 4000, Mediana con un precio de 8000 y Grande con un precio de 12000");
    }
    
    public void verTamaño() {
        JOptionPane.showMessageDialog(null,"Los diferentes tamaños que tenemos son: Pequeña con 4 prociones, Mediana con 8 porciones y Grande con 12 porciones");
    }
    public void verAcompañamiento() {
        JOptionPane.showMessageDialog(null,"Los acompañamientos que ofrecemos son: Refresco, Pan de Ajo, Breadsticks y Salsas");
    }
    public void verRestaurante() {
        JOptionPane.showMessageDialog(null,"Los restaurantes que por el momento tenemos disponibles son: Fidepizza ubicado en San Pedro");
    }
    public void verNumero() {
        JOptionPane.showMessageDialog(null, "Nuestro numero para recibir quejas o sugerencias es 22708940");
    }
}