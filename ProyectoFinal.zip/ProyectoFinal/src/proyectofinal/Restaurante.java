package proyectofinal;
import javax.swing.JOptionPane;
public class Restaurante {
    private String nombre;
    private String ubicacionRes;
    private int numero;
    private String email;
    
    public Restaurante() {
        this.nombre= "";
        this.ubicacionRes= "";
        this.numero= 0;
        this.email= "";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacionRes() {
        return ubicacionRes;
    }

    public void setUbicacionRes(String ubicacionRes) {
        this.ubicacionRes = ubicacionRes;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
}
