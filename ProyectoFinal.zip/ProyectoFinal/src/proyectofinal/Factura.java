package proyectofinal;
import javax.swing.JOptionPane;
public class Factura {
    private int numeroFactura;
    private String fecha;
    private double montoTotal;
    private String cliente;
    private String nombreVendedor;
    private String metodoPago;
    
    public Factura() {
        this.numeroFactura= 0;
        this.fecha= "";
        this.montoTotal= 0.00;
        this.cliente= "";
        this.nombreVendedor= "";
        this.metodoPago= "";
    }

    public int getNumeroFactura() {
        return numeroFactura;
    }

    public void setNumeroFactura(int numeroFactura) {
        this.numeroFactura = numeroFactura;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getNombreVendedor() {
        return nombreVendedor;
    }

    public void setNombreVendedor(String nombreVendedor) {
        this.nombreVendedor = nombreVendedor;
    }

    public String getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(String metodoPago) {
        this.metodoPago = metodoPago;
    }
    
}
