package proyectofinal;

public class Main {

    public static void main(String[] args) {
        Rutina r= new Rutina();
        r.mostrarMenu();
        r.llenarArreglo();
        r.mostrarArreglo();
        r.crearDescuento();
        r.crearCodigoReferencia();
        r.verMenu();
        r.verPrecio();
        r.verTamaño();
        r.verAcompañamiento();
        r.verRestaurante();
        r.verNumero();
        

    }
    
}
