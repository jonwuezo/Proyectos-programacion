package proyectofinal;
import javax.swing.JOptionPane;
public class Descuento {
    private double porcentajeDescuento;
    private double precioTotal;
    private double precioProducto;
    
    public Descuento() {
        this.porcentajeDescuento= 0.00;
        this.precioTotal= 0.00;
        this.precioProducto= 0.00;
    }

    public double getProcentajeDescuento() {
        return porcentajeDescuento;
    }

    public void setProcentajeDescuento(double procentajeDescuento) {
        this.porcentajeDescuento = procentajeDescuento;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }
    
    
    
}
